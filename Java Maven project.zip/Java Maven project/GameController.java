package com.example.ping_pong_game;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;

public class GameController {
    @FXML private Pane gamePane;
    @FXML private Rectangle paddleLeft;
    @FXML private Rectangle paddleRight;
    @FXML private Circle ball;
    @FXML private Label scoreLabel;
    @FXML private Label player1Name;
    @FXML private Label player2Name;
    @FXML private Label gameOverLabel;

    // Reduced ball speed by 10% (from 3 to 2.7)
    private double ballDX = 3.7;
    private double ballDY = 3.7;
    private double paddleSpeed = 10;
    private int scoreLeft = 0, scoreRight = 0;
    private boolean wPressed = false, sPressed = false, uPressed = false, dPressed = false;
    private boolean gameActive = true;
    private AnimationTimer timer;

    @FXML
    public void initialize() {
        setupGame();
        startGame();
    }

    private void setupGame() {
        // Initialize UI
        paddleLeft.setFill(Color.CYAN);
        paddleRight.setFill(Color.ORANGE);
        ball.setFill(Color.DARKSLATEGRAY);
        gameOverLabel.setVisible(false);

        // Set default names if not set via FXML
        if (player1Name.getText().isEmpty()) player1Name.setText("Player 1");
        if (player2Name.getText().isEmpty()) player2Name.setText("Player 2");

        // Set key listeners
        gamePane.setFocusTraversable(true);
        gamePane.setOnKeyPressed(this::handleKeyPressed);
        gamePane.setOnKeyReleased(this::handleKeyReleased);
        gamePane.requestFocus();

        // Handle window focus
        gamePane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.windowProperty().addListener((obsWin, oldWin, newWin) -> {
                    if (newWin != null) {
                        newWin.focusedProperty().addListener((obsFocus, wasFocused, isFocused) -> {
                            if (isFocused) gamePane.requestFocus();
                        });
                    }
                });
            }
        });
    }

    private void startGame() {
        gameActive = true;
        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (gameActive) {
                    movePaddles();
                    moveBall();
                }
            }
        };
        timer.start();
    }

    private void checkWinCondition() {
        if (scoreLeft >= 21 || scoreRight >= 21) {
            gameActive = false;
            String winner = (scoreLeft >= 21) ? player1Name.getText() : player2Name.getText();
            gameOverLabel.setText(winner + " Wins!\nFinal Score: " + scoreLeft + " - " + scoreRight);
            gameOverLabel.setVisible(true);
        }
    }

    private void movePaddles() {
        if (wPressed) paddleLeft.setY(Math.max(0, paddleLeft.getY() - paddleSpeed));
        if (sPressed) paddleLeft.setY(Math.min(gamePane.getHeight() - paddleLeft.getHeight(), paddleLeft.getY() + paddleSpeed));
        if (uPressed) paddleRight.setY(Math.max(0, paddleRight.getY() - paddleSpeed));
        if (dPressed) paddleRight.setY(Math.min(gamePane.getHeight() - paddleRight.getHeight(), paddleRight.getY() + paddleSpeed));
    }

    private void moveBall() {
        double width = gamePane.getWidth();
        double height = gamePane.getHeight();

        ball.setCenterX(ball.getCenterX() + ballDX);
        ball.setCenterY(ball.getCenterY() + ballDY);

        if (ball.getCenterY() <= ball.getRadius() || ball.getCenterY() >= height - ball.getRadius()) {
            ballDY *= -1;
        }


        if (ball.getBoundsInParent().intersects(paddleLeft.getBoundsInParent())) {
            if (ballDX < 0) {
                ballDX = Math.abs(ballDX) * 1.5; // Reduced speed boost after paddle hit
                double hitPosition = (ball.getCenterY() - paddleLeft.getY()) / paddleLeft.getHeight();
                ballDY = (hitPosition - 0.5) * 5;
            }
        }

        if (ball.getBoundsInParent().intersects(paddleRight.getBoundsInParent())) {
            if (ballDX > 0) {
                ballDX = -Math.abs(ballDX) * 1.5; // Reduced speed boost after paddle hit
                double hitPosition = (ball.getCenterY() - paddleRight.getY()) / paddleRight.getHeight();
                ballDY = (hitPosition - 0.5) * 5;
            }
        }


        if (ball.getCenterX() <= ball.getRadius()) {
            scoreRight++;
            updateScore();
            resetBall();
            checkWinCondition();
        } else if (ball.getCenterX() >= width - ball.getRadius()) {
            scoreLeft++;
            updateScore();
            resetBall();
            checkWinCondition();
        }
    }

    private void updateScore() {
        scoreLabel.setText(scoreLeft + " : " + scoreRight);
    }

    private void resetBall() {
        ball.setCenterX(gamePane.getWidth() / 2);
        ball.setCenterY(gamePane.getHeight() / 2);
        ballDX = Math.random() > 0.9 ? 2.7 : -2.7;
        ballDY = (Math.random() * 5) - 2;
    }

    private void handleKeyPressed(KeyEvent event) {
        if (!gameActive) return;

        switch (event.getCode()) {
            case W -> wPressed = true;
            case S -> sPressed = true;
            case U -> uPressed = true;
            case D -> dPressed = true;
            case R -> resetGame();
        }
    }

    private void handleKeyReleased(KeyEvent event) {
        switch (event.getCode()) {
            case W -> wPressed = false;
            case S -> sPressed = false;
            case U -> uPressed = false;
            case D -> dPressed = false;
        }
    }

    public void resetGame() {
        scoreLeft = 0;
        scoreRight = 0;
        updateScore();
        resetBall();
        gameOverLabel.setVisible(false);
        gameActive = true;
    }

    public void setPlayerNames(String name1, String name2) {
        player1Name.setText(name1);
        player2Name.setText(name2);
    }
}