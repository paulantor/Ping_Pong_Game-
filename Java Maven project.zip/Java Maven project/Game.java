package PongGame;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.jetbrains.annotations.NotNull;

public class Game extends Application {
    public static final int WIDTH = 1000;
    public static final int HEIGHT = WIDTH * 9 / 16;

    private Ball ball;
    private Paddle paddle1;
    private Paddle paddle2;
    private Pane root;
    private Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        root = new Pane();
        initializeGameObjects();
        setupScene(primaryStage);
        startGameLoop();
    }

    private void initializeGameObjects() {
        ball = new Ball(8);
        paddle1 = new Paddle(Color.CYAN, true);
        paddle2 = new Paddle(Color.ORANGE, false);

        root.getChildren().addAll(
                ball.getCircle(),
                paddle1.getRectangle(),
                paddle1.getScoreText(),
                paddle2.getRectangle(),
                paddle2.getScoreText()
        );
    }

    private void setupScene(@NotNull Stage primaryStage) {
        this.primaryStage = primaryStage;
        Scene scene = new Scene(root, WIDTH, HEIGHT, Color.BLACK);

        // Key controls
        scene.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                // Left Paddle
                case W -> paddle1.switchDirection(-1); // Up
                case S -> paddle1.switchDirection(1);  // Down

                // Right Paddle - Using U/D
                case U -> paddle2.switchDirection(-1); // Up
                case D -> paddle2.switchDirection(1);  // Down
            }
        });

        scene.setOnKeyReleased(e -> {
            switch (e.getCode()) {
                case W, S -> paddle1.stop();
                case U, D -> paddle2.stop();
            }
        });

        primaryStage.setTitle("Pong Game - Controls: W/S (Left) | U/D (Right)");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();


        primaryStage.requestFocus();
    }

    private void startGameLoop() {
        new AnimationTimer() {
            @Override
            public void handle(long now) {
                ball.update();
                paddle1.update();
                paddle2.update();

                // Collision with paddles
                if (ball.getCircle().getBoundsInParent().intersects(paddle1.getRectangle().getBoundsInParent())) {
                    ball.changeXDir();
                }
                if (ball.getCircle().getBoundsInParent().intersects(paddle2.getRectangle().getBoundsInParent())) {
                    ball.changeXDir();
                }

                // Scoring
                if (ball.getCircle().getCenterX() >= Game.WIDTH) {
                    paddle1.addPoint();
                    ball.reset();
                }
                if (ball.getCircle().getCenterX() <= 0) {
                    paddle2.addPoint();
                    ball.reset();
                }
            }
        }.start();
    }

    public static int sign(double d) {
        return d >= 0 ? 1 : -1;
    }
}