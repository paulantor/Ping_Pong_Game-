package com.example.ping_pong_game;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HelloController {
    @FXML
    private TextField player1Input;

    @FXML
    private TextField player2Input;

    @FXML
    private Label welcomeText;

    @FXML
    protected void onStartGameClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/ping_pong_game/game-view.fxml"));
            Parent root = loader.load();

            // Get the controller and set player names
            GameController gameController = loader.getController();
            String player1 = player1Input.getText().isEmpty() ? "Player 1" : player1Input.getText();
            String player2 = player2Input.getText().isEmpty() ? "Player 2" : player2Input.getText();
            gameController.setPlayerNames(player1, player2);

            Stage stage = (Stage) player1Input.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Ping Pong Game - " + player1 + " vs " + player2);
            stage.show();
        } catch (Exception e) {
            welcomeText.setText("Error loading game: " + e.getMessage());
            e.printStackTrace();
        }
    }
}