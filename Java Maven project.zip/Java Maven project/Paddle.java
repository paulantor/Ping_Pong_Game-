package PongGame;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class Paddle {
    private final Rectangle rectangle;
    private final Text scoreText;
    private double velocity = 0;
    private final double speed = 10; // Increased speed for better responsiveness
    private int score = 0;
    private final boolean isLeftPaddle;

    public Paddle(Color color, boolean isLeftPaddle) {
        this.isLeftPaddle = isLeftPaddle;
        double width = 20;  // Slightly wider paddles
        double height = 100;

        rectangle = new Rectangle(width, height, color);
        rectangle.setY(Game.HEIGHT / 2 - height / 2);
        rectangle.setX(isLeftPaddle ? 20 : Game.WIDTH - width - 20); // Added margin

        scoreText = new Text("0");
        scoreText.setFont(Font.font("Roboto", 50));
        scoreText.setFill(color);
        updateScorePosition();
    }

    public void addPoint() {
        score++;
        scoreText.setText(Integer.toString(score));
        updateScorePosition();
    }

    private void updateScorePosition() {
        double padding = 25;
        double textWidth = scoreText.getBoundsInLocal().getWidth();
        scoreText.setX(isLeftPaddle ?
                Game.WIDTH/2 - textWidth - padding :
                Game.WIDTH/2 + padding);
        scoreText.setY(50);
    }

    public void update() {
        double newY = rectangle.getY() + velocity;

        // Strict boundary checking
        if (newY < 0) {
            newY = 0;
        } else if (newY > Game.HEIGHT - rectangle.getHeight()) {
            newY = Game.HEIGHT - rectangle.getHeight();
        }

        rectangle.setY(newY);
    }

    public void switchDirection(int direction) {
        // Reset velocity before changing direction
        velocity = 0;
        velocity = speed * direction;
        System.out.println((isLeftPaddle ? "Left" : "Right") +
                " Paddle Velocity: " + velocity);
    }

    public void stop() {
        velocity = 0;
    }

    public Rectangle getRectangle() {
        return rectangle;
    }

    public Text getScoreText() {
        return scoreText;
    }
}