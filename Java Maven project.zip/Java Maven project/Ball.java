package PongGame;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Ball {
    private final Circle circle;
    private double xVel;
    private double yVel;
    private final double speed = 0xa;
    private final double radius;

    public Ball(double radius) {
        this.radius = radius;
        this.circle = new Circle(radius, Color.WHITE);
        reset();
    }

    public void reset() {
        circle.setCenterX(Game.WIDTH / 2);
        circle.setCenterY(Game.HEIGHT / 2);
        xVel = Game.sign(Math.random() * 2 - 1);
        yVel = Game.sign(Math.random() * 2 - 1);
    }

    public void changeXDir() {
        xVel *= -1;
    }

    public void changeYDir() {
        yVel *= -1;
    }

    public void update() {
        circle.setCenterX(circle.getCenterX() + xVel * speed);
        circle.setCenterY(circle.getCenterY() + yVel * speed);

        if (circle.getCenterY() <= radius || circle.getCenterY() >= Game.HEIGHT - radius) {
            changeYDir();
        }
    }

    public Circle getCircle() {
        return circle;
    }
}